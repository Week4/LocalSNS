package xyzkwjbl.viris.ext;

/**
 * Marker interface for generated classes
 */
public interface GeneratedClass {

}
